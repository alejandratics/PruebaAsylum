<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'jmacompa_wp980' );

/** Database username */
define( 'DB_USER', 'jmacompa_wp980' );

/** Database password */
define( 'DB_PASSWORD', '(4pTSW29-1' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'tdzikbtnsxlwswzcc8altkrjc46s4tzsr1akiz6gikiuskxh7t9y9dhwvgox6kjy' );
define( 'SECURE_AUTH_KEY',  'sxxvnqxxorvlzesyqpr53zpxhucllz1njbvkycypdhmdgvrgthlf2u5kobbrko9b' );
define( 'LOGGED_IN_KEY',    'gni0tuq0oljwbmui0kou6gygdbghw5qkxkp2qshdjbbtyerz0qupnfcm84cswifq' );
define( 'NONCE_KEY',        '9m9uob53zqnk7onxtiqm7wotv960lml5s6ciku8h1o26h0h63c6qkn204gerpesb' );
define( 'AUTH_SALT',        'kg9x4rxjlknlvmuqmi7mtxu4sjvotcj9oijuqvwjftqdgjwnysdverije29e7e0c' );
define( 'SECURE_AUTH_SALT', 'oklwu5wegz1ndiw81q661qdlbmqkpfr1rtm4xdsdn4vybwurjnaphmtbduyjh2tz' );
define( 'LOGGED_IN_SALT',   'sgrfjlh3kgkscquc5n41ohaeuc78t9pu1d8pyn64fww5wasnrdbzshakwlxw6owf' );
define( 'NONCE_SALT',       'llgrqa1utsgbmqkv2rdkkatsmtwbjgesvcq2l0ucrl1xjepzi2min68rp8pgjiqd' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpmt_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
